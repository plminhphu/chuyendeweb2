<?php

define('listfolder', 'https://script.google.com/macros/s/AKfycbxvD4Op3H_NYvRPxX9zOSIS-QLRI2ramE5n8_UuFH8ubFF5-4Mm/exec');
define('listfile', 'https://script.google.com/macros/s/AKfycbzs5vZCiZYKlz8Gm5_3Nr4PWYK6TcmaWJ-gYpWNqikIBLyFSYk/exec');

define('createfolder', 'https://script.google.com/macros/s/AKfycbzPy6173iatU9W8I-zzysoAW561y9tLjAOfSpmjq20ycxiF8RuZ/exec');
define('createfile', 'https://script.google.com/macros/s/AKfycbxyKmGTKoZaQvr1Wx8eJc5XkhYSlMmtuBfCc2IdRk-c4Hz96DA/exec');

define('downloadfolder', 'https://script.google.com/macros/s/AKfycbzPy6173iatU9W8I-zzysoAW561y9tLjAOfSpmjq20ycxiF8RuZ/exec');
define('downloadfile', 'https://script.google.com/macros/s/AKfycbzrNImrzL2nbJZJx6pwSRA6ieVxL2TBQ2Y4-uH2OzG-Nih7wXg/exec');

define('uploadfile', 'https://script.google.com/macros/s/AKfycbwqP7n2-IyJNB6_gZws57qUiuOfePcq7ScqDy_G3gIUe_xNGmv1/exec');
define('uploadmultifile', 'https://script.google.com/macros/s/AKfycbyD5ZO7hLOI8mj0eRY_9uMV2Nnuw4eHbbTxxVgWv-5fYclCw03I/exec');
